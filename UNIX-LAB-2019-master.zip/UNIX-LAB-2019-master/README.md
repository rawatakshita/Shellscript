# UNIX-LAB-2019

Follow these Instructions :
1. Fork this repository.
2. Create Folders with your Name and roll number (e.g. 25 Your_name)
3. Add all your programs in that folder
4. Genrate a Pull Request

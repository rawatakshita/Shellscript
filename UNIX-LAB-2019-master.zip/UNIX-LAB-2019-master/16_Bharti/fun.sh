hello()
{
   echo "Good morning"
}
bye()
{
   cal  
}

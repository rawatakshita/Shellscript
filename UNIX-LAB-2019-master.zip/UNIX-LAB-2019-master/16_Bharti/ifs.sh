line="shell scripting is fun:hello this :is:a test"
IFS=:
set $line
echo $1
echo $2
echo $3
echo $4
echo $5
echo $6
echo $7
echo $8
echo $9

grep -i you test_file
grep -i -n you test_file
grep -i -n -c you test_file
grep -i -n -c -v you test_file
grep -i -v you test_file

#!/bin/bash
echo "Hi, I'm sleeping for 5 seconds..."
sleep 5  
echo "all Done."



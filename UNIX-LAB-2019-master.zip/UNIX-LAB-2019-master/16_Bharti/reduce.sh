#!/bin/bash
echo "Generating fancy text using banner command"
banner "Hi 8kush"
echo "compressing a text file"
compress -v unix
echo "uncompressing the text file"
uncompress unix.Z


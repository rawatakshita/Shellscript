#!/bin/bash
echo "Using escape sequences"
echo "Hey World, \nWhats up ?"
echo "Hey World, \rWhats up ?"
echo "Hey World, \tWhats up ?"
echo "Hey World, \b\b\b\b\b\b\bWhats up ?"

#!/bin/bash
cd
echo "list of Home"
ls
echo "list with futher details"
ls -l
echo "another type of list"
ls -a

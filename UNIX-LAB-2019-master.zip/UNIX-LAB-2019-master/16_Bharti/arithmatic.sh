#!/bin/bash
a=30 b=15 c=2 d=5
total=$((a*(b+c)/d))
echo $tota

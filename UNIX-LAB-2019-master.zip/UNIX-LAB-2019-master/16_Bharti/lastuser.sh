#!/bin/bash
echo "last login was-"
lastlog -b 0 -t 100

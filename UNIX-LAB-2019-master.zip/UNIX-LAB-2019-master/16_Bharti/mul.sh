echo "enter two numbers"
read a b
mul=$((a*b))
echo "multiplication is $mul"  


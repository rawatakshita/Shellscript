#!/bin/bash
ls -l
chmod 722 $1
ls -l 
chmod 775 $1
echo "using set command"
set shell programming is cool
echo $1
echo $2
echo $3
echo $4
echo $*

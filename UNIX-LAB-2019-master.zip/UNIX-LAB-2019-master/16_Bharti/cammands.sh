ls ; cal ; banner "hello"

grep -i you test_file > pattern && echo "the task was compleeted"

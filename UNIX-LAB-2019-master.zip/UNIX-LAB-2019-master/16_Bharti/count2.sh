#!/bin/bash
echo the total number items in the current directory is=$#

#!/bin/bash
echo "creating a new file animals"
echo "enter some animal names"
cat > animals
echo "creating a new file sports"
echo "enter some sports names"
cat > sports
echo " -sorting animal names in file"
sort animals
echo " -sorting sport names in file"
sort sports


#!/bin/bash
echo "Calender of current month"
cal
echo "Calender of july 2007"
cal 7 2007
echo "Date is-"
date
echo "date and time are-"
date '+DATE:%m-%y%nTIME:%H:%M:%S'

#!/bin/bash
echo enter first number
read num1
echo enter second number
read num2
mult=$((num1*num2))
echo $mult

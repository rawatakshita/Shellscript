for cmd in `cat cammandlist`
do
	man $cmd >> helpfile
done



echo "enter two numbers"
read a b
div=$((a/b))
echo "division is $div"

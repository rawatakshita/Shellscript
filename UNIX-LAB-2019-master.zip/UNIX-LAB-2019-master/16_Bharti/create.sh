#!/bin/bash
echo "creating files"
touch test1 test2 test3
echo "creating directory"
mkdir test
echo "files and directory are created-"
ls
echo "Changing directory"
cd ~
echo "creating directory in documents"
mkdir Documents/test_folder
cd Documents
ls



